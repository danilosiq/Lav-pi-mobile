package com.example.aplicativolav;

import androidx.fragment.app.Fragment;

public class cart extends Fragment {
}
