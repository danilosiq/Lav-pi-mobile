import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.aplicativolav.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class CartActivity : AppCompatActivity() {

    private lateinit var editTextCep: EditText
    private lateinit var buttonBuscar: Button
    private lateinit var textViewRua: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_cart)

        editTextCep = findViewById(R.id.editText_cep)
        buttonBuscar = findViewById(R.id.button_buscar)
        textViewRua = findViewById(R.id.textView_rua)

        buttonBuscar.setOnClickListener {
            val cep = editTextCep.text.toString().trim()
            if (cep.isEmpty() || cep.length != 8) {
                Toast.makeText(this, "Digite um CEP válido", Toast.LENGTH_SHORT).show()
            } else {
                buscarCep(cep)
            }
        }
    }

    private fun buscarCep(cep: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = URL("https://viacep.com.br/ws/$cep/json/")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"

                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val jsonObject = JSONObject(response)
                val rua = jsonObject.optString("logradouro", "Não encontrada")

                withContext(Dispatchers.Main) {
                    textViewRua.visibility = View.VISIBLE
                    textViewRua.text = "Rua: $rua"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@CartActivity, "Erro ao buscar CEP", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}