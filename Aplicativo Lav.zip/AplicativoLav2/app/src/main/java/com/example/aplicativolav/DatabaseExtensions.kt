package com.example.aplicativolav

import android.content.ContentValues
import signInDataBase

fun signInDataBase.SalvarContato(item:userType): Long{
    val idUser = writableDatabase.insert("usuario", null, ContentValues().apply{
        put("cpf",item.cpf)
        put("password",item.password)
    })

    return idUser
}

fun signInDataBase.Selectuser():List<userType>{
    val sql = "SELECT * FROM usuario"

   val cursor =  readableDatabase.rawQuery(sql,null)


    val returnList = mutableListOf<userType>()
   if(cursor.count > 0){
       while(cursor.moveToNext()){
           val user = userType(

               id = cursor.getInt(cursor.getColumnIndex("id")),
               cpf = cursor.getString(cursor.getColumnIndex("cpf")),
               password = cursor.getString(cursor.getColumnIndex("password"))
           )
           returnList.add(user)

       }
       cursor.close()
   }
return returnList

}