package com.example.aplicativolav

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.aplicativolav.network.Usuario
import com.example.aplicativolav.repository.UserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import signInDataBase // Banco de dados SQLite

class ProfileFragment : Fragment() {

    private lateinit var database: signInDataBase
    private val userRepository = UserRepository()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_profile, container, false)

        database = signInDataBase(requireContext())

        val recyclerView = view.findViewById<RecyclerView>(R.id.profile_recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val profileItems = listOf(
            ProfileItem("Cupons"),
            ProfileItem("Histórico"),
            ProfileItem("Endereços"),
            ProfileItem("Dados da Conta")
        )

        val txtUsuarios = view.findViewById<TextView>(R.id.txtUsuarios)
        val editTextCEP = view.findViewById<EditText>(R.id.editTextCEP)
        val buttonBuscarCEP = view.findViewById<Button>(R.id.buttonBuscarCEP)
        val txtEndereco = view.findViewById<TextView>(R.id.txtEndereco)

        val usuariosSQLite = database.Selectuser()

        val usuariosTextoSQLite = usuariosSQLite.joinToString(separator = "\n") {
            "ID: ${it.id}, CPF: ${it.cpf}, Senha: ${it.password}"
        }
        txtUsuarios.text = usuariosTextoSQLite

        lifecycleScope.launch {
            try {
                val response = userRepository.getUsuarios()
                if (response.isSuccessful) {
                    val usuariosAPI = response.body() ?: emptyList()
                    val usuariosTextoAPI = usuariosAPI.joinToString(separator = "\n") {
                        "ID: ${it.id}, CPF: ${it.cpf}"
                    }
                    txtUsuarios.text = usuariosTextoSQLite + "\n\n" + usuariosTextoAPI
                } else {
                    txtUsuarios.text = "Erro ao buscar usuários: ${response.code()}"
                }
            } catch (e: Exception) {
                txtUsuarios.text = "Erro ao se comunicar com o servidor: ${e.message}"
            }
        }

        view.findViewById<ImageButton>(R.id.go_home).setOnClickListener {
            Navigation.findNavController(view).navigate(R.id.action_profileFragment_to_homeFragment)
        }

        view.findViewById<Button>(R.id.exit_btn).setOnClickListener {
            Navigation.findNavController(view).navigate(R.id.action_profileFragment_to_login)
        }

        recyclerView.adapter = ProfileAdapter(profileItems)

        // Configurando busca de CEP
        val retrofit = Retrofit.Builder()
            .baseUrl("https://viacep.com.br/ws/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val viaCepService = retrofit.create(ViaCepService::class.java)

        buttonBuscarCEP.setOnClickListener {
            val cep = editTextCEP.text.toString().trim()

            if (cep.length == 8) {
                lifecycleScope.launch {
                    try {
                        val response = withContext(Dispatchers.IO) {
                            viaCepService.getCep(cep)
                        }
                        handleCepResponse(response, txtEndereco)
                    } catch (e: Exception) {
                        txtEndereco.text = "Erro ao buscar CEP: ${e.message}"
                    }
                }
            } else {
                txtEndereco.text = "Digite um CEP válido (8 dígitos)"
            }
        }

        return view
    }

    private fun handleCepResponse(response: Response<ViaCepResponse>, textView: TextView) {
        if (response.isSuccessful) {
            val viaCepResponse = response.body()
            textView.text = viaCepResponse?.logradouro ?: "CEP não encontrado"
        } else {
            textView.text = "Erro: ${response.code()}"
        }
    }
}

data class ViaCepResponse(val logradouro: String)

interface ViaCepService {
    @GET("{cep}/json/")
    suspend fun getCep(@Path("cep") cep: String): Response<ViaCepResponse>
}