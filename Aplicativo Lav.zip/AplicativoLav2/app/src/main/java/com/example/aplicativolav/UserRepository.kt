package com.example.aplicativolav.repository

import com.example.aplicativolav.network.RetrofitClient
import com.example.aplicativolav.network.Usuario

class UserRepository {

    // Função para obter usuários
    suspend fun getUsuarios() = RetrofitClient.apiService.getUsuarios()

    // Função para adicionar um novo usuário
    suspend fun addUsuario(usuario: Usuario) = RetrofitClient.apiService.addUsuario(usuario)
}
