package com.example.aplicativolav.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {
    // Endpoint correto para listar usuários
    @GET("/usuarios")
    suspend fun getUsuarios(): Response<List<Usuario>>

    // Endpoint correto para adicionar um usuário
    @POST("/usuarios")
    suspend fun addUsuario(@Body usuario: Usuario): Response<Usuario>
}


data class Usuario(
    val id: Int? = null,
    val cpf: String,
    val senha: String
)

