package com.example.aplicativolav

data class ClothingItem(
    val name: String,
    val imageResId: Int
)
