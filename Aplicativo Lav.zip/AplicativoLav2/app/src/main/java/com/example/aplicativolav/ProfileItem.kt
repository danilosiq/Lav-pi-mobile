package com.example.aplicativolav

data class ProfileItem(val name: String)
