package com.example.aplicativolav

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.Navigation
import com.example.aplicativolav.network.Usuario
import com.example.aplicativolav.repository.UserRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import signInDataBase


class createUser : Fragment() {

    private val userRepository = UserRepository()
    private lateinit var editUser: EditText
    private lateinit var editPassword:EditText
    private lateinit var btnSalvar: Button

    private lateinit var  dataBase: signInDataBase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_create_user, container, false)

        editUser= view.findViewById(R.id.user)
        editPassword= view.findViewById(R.id.password)
        btnSalvar= view.findViewById(R.id.createProfile_btn)


        btnSalvar.setOnClickListener{
            salvarContato()
        }

        dataBase = signInDataBase(requireContext())


        view.findViewById<TextView>(R.id.go_login).setOnClickListener {
            Navigation.findNavController(view).navigate(R.id.action_createUser_to_login)
        }
        return view
    }

    private fun salvarContato(){

        val newUser = userType(
            cpf = editUser.text.toString(),
            password = editPassword.text.toString()
        )

        val newUserMySql = Usuario(

            cpf = editUser.text.toString(),
            senha = editPassword.text.toString()
        )

    val idContato = dataBase.SalvarContato(newUser)

        if(idContato == -1L){
            Toast.makeText(context, "Erro ao inserir", Toast.LENGTH_SHORT).show()
        }
        else{
            Toast.makeText(context, "Salvo!", Toast.LENGTH_SHORT).show()
        }


        enviarParaServidor(newUserMySql)
    }


    private fun enviarParaServidor(usuario: Usuario) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val response = userRepository.addUsuario(usuario)
                if (response.isSuccessful) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Salvo no servidor!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Erro no servidor", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Erro: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

