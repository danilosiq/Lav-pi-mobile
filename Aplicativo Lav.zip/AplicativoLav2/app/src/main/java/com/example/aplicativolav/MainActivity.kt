package com.example.aplicativolav

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.view.WindowInsetsControllerCompat
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment

class MainActivity : AppCompatActivity() {

    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configuração do Edge-to-Edge
        enableEdgeToEdge()

        // Configuração de navegação
        setupNavigation()

        // Forçar o modo claro
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        setContentView(R.layout.activity_main)
    }

    private fun setupNavigation() {
        // Obter o NavHostFragment corretamente
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainerView)
                as? NavHostFragment
            ?: throw IllegalStateException("NavHostFragment não encontrado")

        // Obter o NavController
        navController = navHostFragment.navController

        // Configuração adicional pode ser feita aqui, se necessário
    }

    private fun enableEdgeToEdge() {
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = true
        window.statusBarColor = android.graphics.Color.TRANSPARENT
    }
}
