package com.example.aplicativolav

data class userType (
    val cpf: String,
    val password: String,
    val id: Int? = null
    )